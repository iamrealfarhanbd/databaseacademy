import React from 'react';

const Privacy = () => {
    return (
        <div>
            <h1 style={{display: 'block', overflow: 'hidden'}}>Privacy Policy</h1>
        </div>
    );
};

export default Privacy;