import React from 'react';

const LandingPages = () => {
    return (
        <div>
            <h1>PPC Landing Pages </h1>
        </div>
    );
};

export default LandingPages;