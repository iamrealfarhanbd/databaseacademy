import React from 'react';

const FreeResourcePage = () => {
    return (
        <div>
            <h1>Free Resource Page</h1>
        </div>
    );
};

export default FreeResourcePage;