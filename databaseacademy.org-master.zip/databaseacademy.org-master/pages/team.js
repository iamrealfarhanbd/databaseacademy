import React from 'react'
import Team from '../components/AboutUS/Team/Team'
import Title from '../components/AboutUS/Team/Title'


export default function team() {
    return (
        <div>
            <Title></Title>
            <Team></Team>
        </div>
    )
}
