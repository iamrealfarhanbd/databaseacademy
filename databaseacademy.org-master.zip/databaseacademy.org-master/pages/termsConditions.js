import React from 'react'
import TermsConditions from '../components/Terms&Conditions/TermsConditions'

export default function termsConditions() {
    return (
        <div>
            <TermsConditions></TermsConditions>
        </div>
    )
}
