import React from 'react'
import Privacy from '../components/Privacy/Privacy'

export default function privacy() {
    return (
        <div>
          <Privacy></Privacy>
        </div>
    )
}
