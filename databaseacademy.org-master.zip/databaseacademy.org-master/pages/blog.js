import React from 'react'
import Blog from '../components/Blog/ClassicGrid/Blog'
import Title from '../components/Blog/ClassicGrid/Title'

export default function blog() {
    return (
        <div>
            <Title></Title>
            <Blog></Blog>
        </div>
    )
}
