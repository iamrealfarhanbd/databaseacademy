import React from 'react'
import Contact from '../components/Courses/Contact'
import Courses from '../components/Courses/Courses'
import TItle from '../components/Courses/TItle'

export default function courses() {
    return (
        <div>
            <TItle></TItle>
            <Courses></Courses>
            <Contact></Contact>
        </div>
    )
}
