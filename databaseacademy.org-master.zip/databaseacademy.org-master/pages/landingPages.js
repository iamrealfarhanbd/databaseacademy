import React from 'react'
import LandingPages from '../components/LandingPages/LandingPages'

export default function landingPages() {
    return (
        <div>
            <LandingPages></LandingPages>
        </div>
    )
}
