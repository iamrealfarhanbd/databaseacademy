import React from 'react'
import FreeResourcePage from '../components/FreeResource/FreeResourcePage'

export default function freeResource() {
    return (
        <div>
            <FreeResourcePage></FreeResourcePage>
        </div>
    )
}
